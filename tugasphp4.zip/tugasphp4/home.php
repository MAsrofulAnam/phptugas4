<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css/home.css">
</head>
<body>
  <section class="home">
    <div class="home-content">
      <h1>Samsung</h1>
      <p>Hai, selamat datang di platform kami yang dirancang untuk mencari beberapa type dari Handphone Samsung .</p>
      <a href="index.php?hal=galery" class="btn">mencari handphone</a>
    </div>

    <div class="home-img">
      <div class="rhombus">
        <img src="./img/samsung1.webp" alt="Smartphone">
      </div>
    </div>
  </section>

</body>
</html>