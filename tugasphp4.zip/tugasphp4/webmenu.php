<?php
// Array asosiatif


// Menu untuk bagian atas (header.php)
$menu_atas = [
    'home' => 'Home',
    'produk' => 'Produk',
    'pesan' => 'Pesan',
    'galery' => 'Galery',
    'gesbuk' => 'Gesbuk'
];

// Menu untuk bagian tengah (isi.php)
$menu_bawah = [
    'home' => 'home.php',
    'produk' => 'produk.php',
    'pesan' => 'pesan.php',
    'galery' => 'galery.php',
    'gesbuk' => 'gesbuk.php'
];

?>