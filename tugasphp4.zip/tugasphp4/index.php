<?php
// Include_once ---> Potongan2 file utuh berupa html
// require_once ---> Poongan file tapi isinya berupa function, class

// Untuk menggabungkan beberapa file menjadi satu web utuh
include_once 'atas.php';
include_once 'isi.php';


?>