<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="css/galery.css">

  <title>galery</title>
</head>
<body>
  <br>
  <h3 align = "center">type Samsung </h3>
<div class="gallery">
  <div class="card">
    <img src="img/a05.png" alt="a05">
  </div>
  <div class="card">
    <img src="img/a22.jpg" alt="a22">
  </div>
  <div class="card">
    <img src="img/a24.jpg" alt="a24">
  </div>
  <div class="card">
    <img src="img/samsung1.webp" alt="s24">
  </div>
</div>
<body>

</body>
</body>
</html>